#include<stdio.h>
_Bool isDigitChar(char input_char){
    if (input_char>='0' && input_char<='9')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

// aaaaaafefnefwnnef
// aaaaaafefnefwnnef
// aaaaaafefnefwnnef
// aaaaaafefnefwnnef
// aaaaaafefnefwnnef