
#ifndef MY_FUNCTIONS_H
#define MY_FUNCTIONS_H

_Bool isDigitChar(char input_char);  // 函数声明

#endif

// aaaaaafefnefwnnef
// aaaaaafefnefwnnef
// aaaaaafefnefwnnef
// aaaaaafefnefwnnef
// aaaaaafefnefwnnef