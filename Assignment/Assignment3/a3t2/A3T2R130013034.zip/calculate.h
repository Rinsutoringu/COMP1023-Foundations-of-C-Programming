#ifndef CALCULATE_H
#define CALCULATE_H

int calculate(int a, char c, int b); // 声明函数

#endif // CALCULATE_H
